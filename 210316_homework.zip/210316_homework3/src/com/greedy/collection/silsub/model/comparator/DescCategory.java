package com.greedy.collection.silsub.model.comparator;

public class DescCategory {

}
