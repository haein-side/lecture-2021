package com.greedy.collection.silsub.view;

import java.util.Scanner;

public class BookMenu {

//	public BookMenu() {};
	
	public void menu() {
		System.out.println("*** 도서 관리 프로그램 **");
		System.out.println("1. 새 도서 추가");
		Scanner sc = new Scanner(System.in);
		
	}
	
	
	
}
